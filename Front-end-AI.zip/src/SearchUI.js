import React, { useState, useRef, useEffect } from 'react';

const SearchUI = () => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [expanded, setExpanded] = useState(false);
  const textareaRef = useRef(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const response = await fetch('http://localhost:8000/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input }),
      });
      if (!response.ok) throw new Error('Search failed');
      const data = await response.json();
      setOutput(data.output);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const postToTwitter = async () => {
    try {
      // Create a tweet text based on the output
      const summarizeOutput = (text) => {
        // Simple summarization logic (can be enhanced)
        const sentences = text.split('. ');
        return sentences.length > 3 ? sentences.slice(0, 3).join('. ') + '.' : text;
      };
  
      const tweetText = summarizeOutput(output);
      const finalTweetText = tweetText.length > 280 ? `${tweetText.substring(0, 277)}...` : tweetText;
  
      // Open Twitter's tweet dialog with the text pre-filled
      window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(finalTweetText)}`, '_blank');
    } catch (err) {
      console.error('Failed to post to Twitter:', err);
    }
  };

  const styles = {
    container: {
      maxWidth: '800px',
      margin: '0 auto',
      padding: '20px',
      fontFamily: 'Arial, sans-serif',
    },
    title: {
      fontSize: '1.5rem',
      fontWeight: 'bold',
      marginBottom: '15px',
      textAlign: 'center',
      color: '#333',
    },
    form: {
      marginBottom: '20px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
    },
    textarea: {
      width: '100%',
      padding: '12px',
      border: '1px solid #ccc',
      borderRadius: '4px',
      resize: 'vertical',
      transition: 'height 0.3s',
      height: expanded ? '150px' : '80px',
      fontSize: '16px',
      fontFamily: 'Arial, sans-serif',
      color: '#333',
      marginBottom: '10px',
    },
    button: {
      width: '120px',
      padding: '10px',
      backgroundColor: '#007bff',
      color: 'white',
      fontSize: '16px',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      textAlign: 'center',
    },
    error: {
      backgroundColor: '#ffeeee',
      color: '#d8000c',
      padding: '10px',
      marginBottom: '10px',
      borderRadius: '4px',
      textAlign: 'center',
    },
    results: {
      backgroundColor: '#fff',
      padding: '20px',
      borderRadius: '8px',
      lineHeight: '1.6',
      fontSize: '16px',
      color: '#333',
      fontFamily: '"Segoe UI", Arial, sans-serif',
      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
      marginBottom: '10px', // Adjusted for spacing
    },
    contentButtonContainer:{
        display:'flex', 
        justifyContent:'space-between', 
        alignItems:'center'
    },
    content:{
        '& h1': { /* Styles */ },
        '& h2': { /* Styles */ },
        '& h3': { /* Styles */ },
        '& p': { /* Styles */ },
        '& ul': { /* Styles */ },
        '& li': { /* Styles */ },
        '& a': { /* Styles */ },
        '& strong': { /* Styles */ },
        '& em': { /* Styles */ },
        '& blockquote': { /* Styles */ },
    }
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (textareaRef.current && !textareaRef.current.contains(event.target)) {
        setExpanded(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div style={styles.container}>
      <div style={styles.title}>Agent - Scrap Collector</div>
      
       <form onSubmit={handleSubmit} style={styles.form}>
        <textarea
          ref={textareaRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onClick={() => setExpanded(true)}
          style={styles.textarea}
          placeholder="Enter your search query..."
        />
        <button type="submit" disabled={loading} style={styles.button}>
          {loading ? 'Searching...' : 'Search'}
        </button>
       </form>

       {error && <div style={styles.error}><strong>Error:</strong> {error}</div>}

       {output && (
         <div style={styles.results}>
           <h2>Search Results:</h2>
           <div 
             className="search-content"
             dangerouslySetInnerHTML={{ __html: output }} 
             style={styles.content}
           />
           <div style={styles.contentButtonContainer}>
               <button onClick={postToTwitter} style={styles.button}>
                   Share on Twitter
               </button>
           </div>
         </div>
       )}
     </div>
   );
};

export default SearchUI;